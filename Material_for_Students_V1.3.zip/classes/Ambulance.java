package classes;

import interfaces.I_Ambulance;

public class Ambulance implements I_Ambulance {

	@Override
	public String getID() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setID(String ID) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean getHasDoctor() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setHasDoctor(boolean hasDoctor) {
		// TODO Auto-generated method stub
		
	}

}
