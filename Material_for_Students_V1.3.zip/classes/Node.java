package classes;

import interfaces.I_Node;

public class Node <T> implements I_Node <T> {

	@Override
	public T getContent() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setContent(T content) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Node<T> getPrev() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setPrev(Node<T> prev) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Node<T> getNext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setNext(Node<T> next) {
		// TODO Auto-generated method stub
		
	}

}
