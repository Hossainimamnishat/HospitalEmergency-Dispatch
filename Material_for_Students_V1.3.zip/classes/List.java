package classes;

import classes.*;
import interfaces.I_List;

public class List <T> implements I_List <T> {

	@Override
	public Node<T> getHead() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Node<T> getTail() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean insert(int index, Node<T> node) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean append(Node<T> node) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(int index) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(T content) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Node<T> get(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean swap(int indexOne, int indexTwo) {
		// TODO Auto-generated method stub
		return false;
	}

}
