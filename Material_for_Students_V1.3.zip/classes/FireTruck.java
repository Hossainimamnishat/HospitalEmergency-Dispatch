package classes;

import interfaces.I_FireTruck;

public class FireTruck implements I_FireTruck {

	@Override
	public String getID() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setID(String ID) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public FireTruckKinds getKind() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setKind(FireTruckKinds kind) {
		// TODO Auto-generated method stub
		
	}

}
