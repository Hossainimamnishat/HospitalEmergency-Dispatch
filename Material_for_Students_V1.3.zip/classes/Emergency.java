package classes;

import interfaces.I_Emergency;

public class Emergency implements I_Emergency {

	@Override
	public String getLocation() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setLocation(String location) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public EmergencyKinds getKind() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setKind(EmergencyKinds kind) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getCasualties() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setCasualties(int casualties) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getCasualtiesNeedsDoctor() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setCasualtiesNeedsDoctor(int casualtiesNeedsDoctor) {
		// TODO Auto-generated method stub
		
	}

}
