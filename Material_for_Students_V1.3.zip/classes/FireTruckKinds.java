package classes;

public enum FireTruckKinds {

}
