package classes;

public enum EmergencyKinds {

}
