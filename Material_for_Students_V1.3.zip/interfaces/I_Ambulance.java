package interfaces;

public interface I_Ambulance {
	public String getID();
	public void setID(String ID);
	public boolean getHasDoctor();
	public void setHasDoctor(boolean hasDoctor);
}
